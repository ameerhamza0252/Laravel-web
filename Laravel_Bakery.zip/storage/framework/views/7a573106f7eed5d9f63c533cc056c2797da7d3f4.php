<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <title>Home</title>
    <style>
        .des{
            color:#5D6D7E;
            text-align:center;
            align-items:center;
            font-size:12px;
            min-height:100px;
            width:100%;
            overflow:hidden;
        }
        .pricetag{
            font-size:1.5rem;
            color:#DC7633;
            line-height:20px;
            text-align:center;
        }
        .card{
            display:flex;
            flex-direction:column;
            box-shadow:1px 1px 4px 1px #88898A;
            padding:12px;
            width:18rem;
            height:25rem;
            gap:10px;
            border-radius:10px;
            align-items:center;
        }
        .title{
            background-color:#DC7633;
            color:#fff;
            width:15rem;
            font-size:18px;
            text-align:center;
            border-top-left-radius:50px;
            border-Bottom-Right-Radius:50px;
        }
        .btn{
            background-color:#DC7633;
            color:#fff;
            border:none;
            transition:0.2s;
        }
        .heading{
            width:80%;
            margin:auto;
            font-size:1.3rem;
            text-align:center;
            margin-top:10vh;

        }
        .card-img-top:hover{
            scale:1.1;
            transform:rotate(5deg);
        }
        .header{
        position: sticky;
        top: 0%;
        width:100vw;
        height: 10vh;
        background-color: #DC7633;
        font-size:15px;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        align-content: center;
        color: #ffff;
        z-index: 1;
        }
        .header i{
        color: #fff;
        display: block;
        width:5rem;
        font-size: 17px;
        text-decoration:none;
        text-decoration-line:none;
        text-decoration-color: #181a1d;
        transition: 0.5s;
        }
        .header ul{
        list-style: none;
        text-decoration: none;
        height:2rem;
        align-items:center;
        color:#fff;
        display: flex;
        gap: 30px;
        margin-right:2vw;
        }
        .header ul i:hover{
        color: #ddd;
        scale: 1.1;
        }
    </style>
</head>
<body>
<div class="header">
        <h2>Bunny Bakers</h2>
        <div class="header_list" id="top">
            <ul>
                <li><a href="/Home"><i class="fa fa-fw fa-home txt02">Home</i></a></li>
                <li><a href="./Cart"><i class="fa fa-fw fa-briefcase txt02"> Cart</i></a></li>
                <li><a href="./Contact"><i class="fa fa-fw fa-envelope txt02"> Contact</i></a></li>
                <li><a href="./About"><i class="fa fa-fw fa-group txt02"> About</i></a></li>
            </ul>
        </div>
    </div>
    <div><h5 class="title heading" >Products</h5></div>
    <div style="display:flex; flex-direction:row; flex-wrap:wrap; padding:10px; gap:10px; min-height:100vh;justify-content:center;width:80%;margin:auto;margin-top:5vh;">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card">
        <div><img class="card-img-top" src="uploads/<?php echo e(($item->image)); ?>" alt="Card image cap" style="width:100px;height:100px;object-fit:contain;margin:auto;transition:0.2s;"></div>
        <div><h5 class="title" ><?php echo e($item->Pname); ?></h5></div>
        <div><h5 class="card-title pricetag"><?php echo e($item->Price); ?>$</h5></div>
        <div  class="card-text des"><span><?php echo e($item->Description); ?></span></div>
        <div>
            <a href="cart-index/<?php echo e($item->id); ?>" class="btn btn-primary">Add To Cart</a>
        </div>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                No data Found
            <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\New folder\bakery\resources\views//product/Home.blade.php ENDPATH**/ ?>