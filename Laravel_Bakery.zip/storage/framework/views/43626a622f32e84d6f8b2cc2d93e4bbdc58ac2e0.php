<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <style>
        .Options{
            display:flex;
            justify-content:center;
            align-items:center;
            color:#fff;
            min-width:12rem;
            height:5rem;
            background-color:#203354;
            padding:10px;
            border-radius:10px;
            transition:0.2s;
        }
        .Options:hover{
            transform:translateY(-5px)
        }
        .container{
            display:flex;
            flex-direction:row;
            flex-wrap:wrap;
            gap:10px;
            text-align:center;
            max-width:100%;
            margin:auto;
            align-items:center;
            justify-content:center;
            margin-top:5vh;
        }
    </style>
</head>
<body>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight Options">
            Bunny Baker's Admin Panel
        </h2>
        <div class="container">
            <a href="<?php echo e(url('/products')); ?>" class="Options">Listed Products</a>
            <a href="<?php echo e(url('/addproductview')); ?>" class="Options">Add Product</a>
            <a href="<?php echo e(url('/')); ?>" class="Options">Home</a>
            <a href="<?php echo e(url('/profile')); ?>" class="Options">Admin Profile</a>
            <a href="<?php echo e(url('/Admin')); ?>" class="Options">Admin Panel</a>
        </div>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\New folder\bakery\resources\views/dashboard.blade.php ENDPATH**/ ?>